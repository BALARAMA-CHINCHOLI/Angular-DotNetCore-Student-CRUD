﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using student_CURDwebAPI.Model;
using System.Diagnostics.Eventing.Reader;

namespace student_CURDwebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    [EnableCors("CorsPolicy")]

    public class StudentMasterController : ControllerBase
    {
        private readonly StudentDbContext _context;

        public StudentMasterController(StudentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetStudent()
        {
            List<Student> student = _context.Students.ToList(); 
            return Ok(student);
        }
        [HttpPost]
        public IActionResult SaveStudent(Student student)
        {
            _context.Students.Add(student);
            _context.SaveChanges();
            return Ok(student);
        }
        [HttpPut]
        public IActionResult UpdateStudents(Student student)
        {
            var record = _context.Students.Find(student.studentId);
            if (record == null)
            {
                var notFoundResponse = new
                {
                    StatusCode = "Error",
                    Message = "Student not found."
                };
                return NotFound(notFoundResponse);
            }
            else
            {
                record.studentId = student.studentId;
                record.studName = student.studName;
                record.mobile = student.mobile;
                record.email = student.email;
                record.city = student.city;
                record.state = student.state;
                record.pincode = student.pincode;
                record.addressLine1 = student.addressLine1;
                record.addressLine2 = student.addressLine2;
                _context.SaveChanges();
                return Ok(record);
            }
        }
        [HttpDelete]
        public IActionResult DeleteStudentById(int id)
        {
            var record = _context.Students.Find(id);
            if (record != null)
            {
                _context.Students.Remove(record);
                _context.SaveChanges();
                return Ok(record);
            }
            else {
                var notFoundResponse = new
                {
                    status = "Error",
                    Message = "Student Record Not found",
                };
                return NotFound(notFoundResponse);
            }
        }
    }
} 