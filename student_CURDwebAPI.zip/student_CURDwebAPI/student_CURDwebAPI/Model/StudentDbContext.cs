﻿using Microsoft.EntityFrameworkCore;

namespace student_CURDwebAPI.Model
{
    public class StudentDbContext(DbContextOptions<StudentDbContext> options) : DbContext(options)
    {
        public DbSet<Student> Students { get; set; }
        public object? Student { get; internal set; } 
    }
}
