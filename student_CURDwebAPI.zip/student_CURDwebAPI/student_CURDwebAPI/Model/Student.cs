﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace student_CURDwebAPI.Model
{
    [Table ("studentMaster")] 
    public class Student
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int studentId { get; set; }

        [Required]
        public string studName { get; set; } = string.Empty;

        [Required, MaxLength(10)]
        public string mobile { get; set; } = string.Empty;

        [Required, EmailAddress]
        public string email { get; set; } = string.Empty;

        public string city { get; set; } = string.Empty;

        public string state { get; set; } = string.Empty;

        public string pincode { get; set; } = string.Empty;

        public string addressLine1 { get; set; } = string.Empty;

        public string addressLine2 { get; set; } = string.Empty;
    }
}
