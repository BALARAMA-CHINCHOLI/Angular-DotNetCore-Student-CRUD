using Microsoft.EntityFrameworkCore;
using student_CURDwebAPI.Model;

var builder = WebApplication.CreateBuilder(args);

//1.Register Controller services
builder.Services.AddControllers();

/*The 'AddDbContext method registers the StudentDbContext class with the dependency injection container, allowing it to
   be injected into controllers or other services that require database access.*/
/*The UseSqlServer method configures the DbContext to use SQL Server as the database provider, and it retrieves the 
 connection string from the application's configuration settings.*/
// This allows the application to connect to the specified SQL Server database when performing CRUD operations on the Student entity.
// Register the StudentDbContext with the dependency injection container
// The connection string is retrieved from the configuration settings (appsettings.json or other configuration sources).
// The "DefaultConnection" key corresponds to the connection string defined in the configuration file.
builder.Services.AddDbContext<StudentDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("StudentCon")));

//Fix CORS issue to coonect the two different origin/domain 
builder.Services.AddCors(opt =>
  opt.AddPolicy("CorsPolicy", policy =>
  {
      policy.AllowAnyHeader().AllowCredentials().AllowAnyMethod().WithOrigins("http://localhost:4200");
  }) // <-- Added missing parenthesis here
);

var app = builder.Build();

//Conigure the HTPP request pipeline
app.UseCors("CorsPolicy");

app.UseHttpsRedirection();

app.UseAuthorization();

//Map controller endpoints
app.MapControllers();

app.Run();
