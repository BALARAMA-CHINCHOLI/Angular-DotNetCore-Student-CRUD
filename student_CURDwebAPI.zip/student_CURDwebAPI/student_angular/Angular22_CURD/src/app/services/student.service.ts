import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from '../model/student.model';

@Injectable({ providedIn: 'root' })
export class StudentService {
  private http = inject(HttpClient);

  // Change this to your backend URL
  private readonly baseUrl = 'https://localhost:7218/api/StudentMaster';

  /** GET /api/students */
  getAll(): Observable<Student[]> {
    return this.http.get<Student[]>(this.baseUrl);
  }

  /** GET /api/students/{id} */
  getById(id: number): Observable<Student> {
    return this.http.get<Student>(`${this.baseUrl}/${id}`);
  }

  /** POST /api/students  (server assigns the "student" id) */
  create(data: Omit<Student, 'studentId'>): Observable<Student> {
    return this.http.post<Student>(this.baseUrl, data);
  }

  /** PUT /api/students/{id} */
  // update(id: number, data: Student): Observable<Student> {
  //   return this.http.put<Student>(`${this.baseUrl}/${id}`, data);
  // }

  //New update method without id in URL
  update(id: number, data: Student): Observable<Student> {
  return this.http.put<Student>(this.baseUrl, data);
}

  /** DELETE /api/students/{id} */
  // delete(id: number): Observable<void> {
  //   return this.http.delete<void>(`${this.baseUrl}/${id}`);
  // }

  //updated delete method by 'Observable<void>' =>'Observable<Student>' and adding id as query parameter
  delete(id: number): Observable<Student> {
  return this.http.delete<Student>(`${this.baseUrl}?id=${id}`);
}
}
