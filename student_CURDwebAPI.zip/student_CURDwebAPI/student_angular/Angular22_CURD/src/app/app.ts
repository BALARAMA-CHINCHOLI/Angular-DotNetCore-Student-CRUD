import { Component, OnInit, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { StudentService } from './services/student.service';
import { Student } from './model/student.model';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [ReactiveFormsModule, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(StudentService);

  students = signal<Student[]>([]);
  editingId = signal<number | null>(null);
  loading = signal(false);
  errorMsg = signal('');

  form = this.fb.nonNullable.group({
    studentId: [0],
    studName: ['', Validators.required],
    mobile: ['', [Validators.required, Validators.pattern(/^[0-9]{9,11}$/)]],
    email: ['', [Validators.required, Validators.email]],
    city: ['', Validators.required],
    state: ['', Validators.required],
    addressLine1: [''],
    addressLine2: [''],
});

  ngOnInit() {
    this.loadStudents();
  }

  // READ (GET)
  loadStudents() {
    this.loading.set(true);
    this.errorMsg.set('');
    this.api.getAll().subscribe({
      next: list => {
        this.students.set(list);
        this.loading.set(false);
      },
      error: () => {
        this.loading.set(false);
        this.errorMsg.set('Could not load students. Is the API running?');
      },
    });
  }

  // CREATE (POST) + UPDATE (PUT)
  onSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const data = this.form.getRawValue();
    const id = this.editingId();
    this.errorMsg.set('');

    if (id !== null) {
      this.api.update(id, { ...data, studentId: id }).subscribe({
        next: updated => {
          this.students.update(list => list.map(s => (s.studentId === id ? updated : s)));
          this.onCancel();
        },
        error: () => this.errorMsg.set('Update failed.'),
      });
    } else {
      this.api.create(data).subscribe({
        next: created => {
          this.students.update(list => [...list, created]);
          this.onCancel();
        },
        error: () => this.errorMsg.set('Could not save the student.'),
      });
    }
  }

  // Load a row into the form
  onEdit(s: Student) {
    this.editingId.set(s.studentId);
    this.form.patchValue(s);
  }

  // DELETE
  onDelete(id: number) {
    if (!confirm('Delete this student?')) return;
    this.errorMsg.set('');
    this.api.delete(id).subscribe({
      next: () => {
        this.students.update(list => list.filter(s => s.studentId !== id));
        if (this.editingId() === id) this.onCancel();
      },
      error: () => this.errorMsg.set('Delete failed.'),
    });
  }

  // CANCEL / reset
  onCancel() {
    this.editingId.set(null);
    this.form.reset();
  }

  invalid(name: string) {
    const c = this.form.get(name);
    return !!c && c.invalid && (c.touched || c.dirty);
  }
}
