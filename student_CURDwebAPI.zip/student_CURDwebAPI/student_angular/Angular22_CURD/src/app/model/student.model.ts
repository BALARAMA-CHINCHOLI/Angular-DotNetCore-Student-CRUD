export interface Student {
  studentId: number;
  studName: string;
  mobile: string;
  email: string;
  city: string;
  state: string;
  addressLine1: string;
  addressLine2: string;
}
